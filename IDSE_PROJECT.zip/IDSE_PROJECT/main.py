"""
Block Puzzle — move and rotate falling blocks to complete rows.
Built with Kivy. Run:  python main.py

Keyboard
  Left / Right (or A / D)   move
  Up / X                    rotate clockwise
  Z                         rotate counter-clockwise
  Down (or S)               soft drop
  Space                     hard drop
  C / Shift                 hold piece
  P / Esc                   pause
  R                         new game

Touch (on the board)
  tap            rotate
  drag sideways  move
  drag down      soft drop
  flick down     hard drop
  flick up       hold
Plus on-screen buttons below the board.
"""
import json
import os
import random

from kivy.config import Config

Config.set("kivy", "exit_on_escape", "0")
Config.set("graphics", "width", "480")
Config.set("graphics", "height", "820")

from kivy.app import App  # noqa: E402
from kivy.clock import Clock  # noqa: E402
from kivy.core.window import Window  # noqa: E402
from kivy.graphics import Color, Line, Rectangle  # noqa: E402
from kivy.metrics import dp, sp  # noqa: E402
from kivy.uix.boxlayout import BoxLayout  # noqa: E402
from kivy.uix.button import Button  # noqa: E402
from kivy.uix.gridlayout import GridLayout  # noqa: E402
from kivy.uix.label import Label  # noqa: E402
from kivy.uix.widget import Widget  # noqa: E402

# --------------------------------------------------------------------------
# Game rules (pure Python, no Kivy)
# --------------------------------------------------------------------------
COLS, ROWS = 10, 20

SHAPES = {
    "I": [[0, 0, 0, 0], [1, 1, 1, 1], [0, 0, 0, 0], [0, 0, 0, 0]],
    "O": [[1, 1], [1, 1]],
    "T": [[0, 1, 0], [1, 1, 1], [0, 0, 0]],
    "S": [[0, 1, 1], [1, 1, 0], [0, 0, 0]],
    "Z": [[1, 1, 0], [0, 1, 1], [0, 0, 0]],
    "J": [[1, 0, 0], [1, 1, 1], [0, 0, 0]],
    "L": [[0, 0, 1], [1, 1, 1], [0, 0, 0]],
}

COLORS = {
    "I": (0.20, 0.85, 0.95),
    "O": (0.98, 0.85, 0.20),
    "T": (0.70, 0.35, 0.95),
    "S": (0.35, 0.85, 0.35),
    "Z": (0.95, 0.30, 0.35),
    "J": (0.25, 0.45, 0.95),
    "L": (0.98, 0.55, 0.15),
}

LINE_SCORES = {1: 100, 2: 300, 3: 500, 4: 800}
# Offsets tried when a rotation is blocked (simple wall/floor kicks).
KICKS = [(0, 0), (-1, 0), (1, 0), (0, -1), (-2, 0), (2, 0), (-1, -1), (1, -1)]


def rotate_cw(m):
    return [list(r) for r in zip(*m[::-1])]


def rotate_ccw(m):
    return [list(r) for r in zip(*m)][::-1]


class Board:
    """Holds the grid, the falling piece and all scoring rules."""

    def __init__(self, rng=None):
        self.rng = rng or random.Random()
        self.reset()

    def reset(self):
        self.grid = [[None] * COLS for _ in range(ROWS)]
        self.bag = []
        self.queue = [self._from_bag() for _ in range(3)]
        self.score = 0
        self.lines = 0
        self.level = 1
        self.hold = None
        self.can_hold = True
        self.game_over = False
        self.last_clear = 0
        self.spawn()

    # 7-bag randomizer: every piece appears once per 7 draws.
    def _from_bag(self):
        if not self.bag:
            self.bag = list(SHAPES)
            self.rng.shuffle(self.bag)
        return self.bag.pop()

    def spawn(self, kind=None):
        if kind is None:
            kind = self.queue.pop(0)
            self.queue.append(self._from_bag())
        self.kind = kind
        self.matrix = [row[:] for row in SHAPES[kind]]
        self.x = (COLS - len(self.matrix[0])) // 2
        self.y = -1 if kind == "I" else 0
        if self.collides(self.matrix, self.x, self.y):
            self.game_over = True

    def collides(self, matrix, x, y):
        for r, row in enumerate(matrix):
            for c, v in enumerate(row):
                if not v:
                    continue
                gx, gy = x + c, y + r
                if gx < 0 or gx >= COLS or gy >= ROWS:
                    return True
                if gy >= 0 and self.grid[gy][gx]:
                    return True
        return False

    def piece_cells(self, y=None):
        y = self.y if y is None else y
        return [
            (self.x + c, y + r)
            for r, row in enumerate(self.matrix)
            for c, v in enumerate(row)
            if v
        ]

    def move(self, dx, dy):
        if self.game_over:
            return False
        if not self.collides(self.matrix, self.x + dx, self.y + dy):
            self.x += dx
            self.y += dy
            return True
        return False

    def rotate(self, clockwise=True):
        if self.game_over or self.kind == "O":
            return False
        m = rotate_cw(self.matrix) if clockwise else rotate_ccw(self.matrix)
        for dx, dy in KICKS:
            if not self.collides(m, self.x + dx, self.y + dy):
                self.matrix = m
                self.x += dx
                self.y += dy
                return True
        return False

    def ghost_y(self):
        y = self.y
        while not self.collides(self.matrix, self.x, y + 1):
            y += 1
        return y

    def soft_drop(self):
        """Move down one row (+1 point). Locks the piece if it can't move."""
        if self.move(0, 1):
            self.score += 1
            return True
        self.lock()
        return False

    def hard_drop(self):
        if self.game_over:
            return
        gy = self.ghost_y()
        self.score += 2 * (gy - self.y)
        self.y = gy
        self.lock()

    def tick(self):
        """Gravity step."""
        if self.game_over:
            return
        if not self.move(0, 1):
            self.lock()

    def lock(self):
        if self.game_over:
            return
        overflow = False
        for gx, gy in self.piece_cells():
            if gy < 0:
                overflow = True
            else:
                self.grid[gy][gx] = self.kind
        if overflow:
            self.game_over = True
            return

        kept = [row for row in self.grid if not all(row)]
        cleared = ROWS - len(kept)
        self.grid = [[None] * COLS for _ in range(cleared)] + kept
        self.last_clear = cleared
        if cleared:
            self.score += LINE_SCORES[cleared] * self.level
            self.lines += cleared
            self.level = self.lines // 10 + 1

        self.can_hold = True
        self.spawn()

    def hold_piece(self):
        if self.game_over or not self.can_hold:
            return False
        current = self.kind
        if self.hold is None:
            self.hold = current
            self.spawn()
        else:
            swap = self.hold
            self.hold = current
            self.spawn(swap)
        self.can_hold = False
        return True

    @property
    def gravity_interval(self):
        return max(0.05, 0.8 * (0.85 ** (self.level - 1)))


# --------------------------------------------------------------------------
# Drawing helpers
# --------------------------------------------------------------------------
BOARD_BG = (0.07, 0.08, 0.12)


def draw_block(px, py, size, rgb, alpha=1.0):
    """A bevelled square block. Call inside a `with canvas:` block."""
    Color(*rgb, alpha)
    Rectangle(pos=(px + 1, py + 1), size=(size - 2, size - 2))
    Color(1, 1, 1, 0.28 * alpha)
    Rectangle(pos=(px + 1, py + size - 1 - size * 0.18), size=(size - 2, size * 0.18))
    Color(0, 0, 0, 0.28 * alpha)
    Rectangle(pos=(px + 1, py + 1), size=(size - 2, size * 0.12))


class BoardView(Widget):
    """Draws the playfield and handles touch gestures on it."""

    def __init__(self, app, **kw):
        super().__init__(**kw)
        self.app = app
        self.message = Label(
            font_size=sp(24), bold=True, halign="center", valign="middle", markup=True
        )
        self.add_widget(self.message)
        self.bind(pos=self.redraw, size=self.redraw)

    def geometry(self):
        cell = min(self.width / COLS, self.height / ROWS)
        ox = self.x + (self.width - cell * COLS) / 2
        oy = self.y + (self.height - cell * ROWS) / 2
        return cell, ox, oy

    def redraw(self, *_):
        b = self.app.board
        cell, ox, oy = self.geometry()
        w, h = cell * COLS, cell * ROWS

        def px(gx, gy):
            return ox + gx * cell, oy + (ROWS - 1 - gy) * cell

        cv = self.canvas.before  # children (the message label) live on self.canvas
        cv.clear()
        with cv:
            Color(*BOARD_BG)
            Rectangle(pos=(ox, oy), size=(w, h))
            Color(1, 1, 1, 0.05)
            for c in range(1, COLS):
                Line(points=[ox + c * cell, oy, ox + c * cell, oy + h])
            for r in range(1, ROWS):
                Line(points=[ox, oy + r * cell, ox + w, oy + r * cell])

            for gy, row in enumerate(b.grid):
                for gx, kind in enumerate(row):
                    if kind:
                        draw_block(*px(gx, gy), cell, COLORS[kind])

            if not b.game_over:
                rgb = COLORS[b.kind]
                for gx, gy in b.piece_cells(b.ghost_y()):
                    if gy >= 0:
                        x, y = px(gx, gy)
                        Color(*rgb, 0.18)
                        Rectangle(pos=(x + 1, y + 1), size=(cell - 2, cell - 2))
                        Color(*rgb, 0.5)
                        Line(rectangle=(x + 2, y + 2, cell - 4, cell - 4), width=1)
                for gx, gy in b.piece_cells():
                    if gy >= 0:
                        draw_block(*px(gx, gy), cell, rgb)

            Color(0.40, 0.45, 0.60, 1)
            Line(rectangle=(ox, oy, w, h), width=1.5)

            text = ""
            if b.game_over:
                text = (
                    f"GAME OVER\n[size={int(sp(16))}]Score {b.score}\n"
                    f"Tap New or press R[/size]"
                )
            elif self.app.paused:
                text = f"PAUSED\n[size={int(sp(16))}]Tap Resume or press P[/size]"
            if text:
                Color(0, 0, 0, 0.6)
                Rectangle(pos=(ox, oy), size=(w, h))

        self.message.text = text
        self.message.pos = self.pos
        self.message.size = self.size
        self.message.text_size = self.size

    # ---- touch gestures -------------------------------------------------
    def on_touch_down(self, touch):
        if not self.collide_point(*touch.pos):
            return super().on_touch_down(touch)
        touch.grab(self)
        touch.ud["bp"] = {"x": touch.x, "y": touch.y, "t": touch.time_start, "mx": 0, "my": 0}
        return True

    def on_touch_move(self, touch):
        if touch.grab_current is not self:
            return super().on_touch_move(touch)
        st = touch.ud["bp"]
        if not self.app.can_play():
            return True
        cell = self.geometry()[0]
        # Horizontal: one column per cell of drag distance.
        target_x = int((touch.x - st["x"]) / cell)
        while st["mx"] < target_x:
            self.app.board.move(1, 0)
            st["mx"] += 1
        while st["mx"] > target_x:
            self.app.board.move(-1, 0)
            st["mx"] -= 1
        # Downward drag: soft drop without locking.
        target_y = int((st["y"] - touch.y) / cell)
        while st["my"] < target_y:
            if self.app.board.move(0, 1):
                self.app.board.score += 1
            st["my"] += 1
        self.app.refresh()
        return True

    def on_touch_up(self, touch):
        if touch.grab_current is not self:
            return super().on_touch_up(touch)
        touch.ungrab(self)
        st = touch.ud["bp"]
        cell = self.geometry()[0]
        dt = touch.time_update - st["t"]
        dx, dy = touch.x - st["x"], touch.y - st["y"]
        if abs(dx) < cell * 0.5 and abs(dy) < cell * 0.5 and dt < 0.35:
            self.app.act("rotate")
        elif dy < -2 * cell and dt < 0.25 and abs(dy) > abs(dx):
            self.app.act("hard_drop")
        elif dy > 2 * cell and dt < 0.3 and abs(dy) > abs(dx):
            self.app.act("hold")
        return True


class PieceView(Widget):
    """Small preview box for the hold piece or the next-piece queue."""

    def __init__(self, slots=1, **kw):
        super().__init__(**kw)
        self.slots = slots
        self.kinds = []
        self.dim = False
        self.bind(pos=self.redraw, size=self.redraw)

    def show(self, kinds, dim=False):
        self.kinds = [k for k in kinds if k]
        self.dim = dim
        self.redraw()

    def redraw(self, *_):
        self.canvas.clear()
        with self.canvas:
            Color(*BOARD_BG)
            Rectangle(pos=self.pos, size=self.size)
            Color(0.40, 0.45, 0.60, 1)
            Line(rectangle=(self.x, self.y, self.width, self.height), width=1.2)
            slot_h = self.height / self.slots
            cell = max(1, min(self.width / 5, slot_h / 3))
            for i, kind in enumerate(self.kinds[: self.slots]):
                cells = [
                    (c, r)
                    for r, row in enumerate(SHAPES[kind])
                    for c, v in enumerate(row)
                    if v
                ]
                minc = min(c for c, _ in cells)
                maxc = max(c for c, _ in cells)
                minr = min(r for _, r in cells)
                maxr = max(r for _, r in cells)
                w = (maxc - minc + 1) * cell
                h = (maxr - minr + 1) * cell
                sx = self.x + (self.width - w) / 2
                top = self.top - i * slot_h - (slot_h - h) / 2
                rgb = COLORS[kind]
                if self.dim:
                    rgb = tuple(0.35 + 0.3 * v for v in rgb)
                for c, r in cells:
                    draw_block(
                        sx + (c - minc) * cell, top - (r - minr + 1) * cell, cell, rgb,
                        alpha=0.5 if self.dim else 1.0,
                    )


class ControlButton(Button):
    """Button that runs an action on press, optionally auto-repeating while held."""

    def __init__(self, action, repeat=False, **kw):
        kw.setdefault("font_size", sp(17))
        kw.setdefault("bold", True)
        kw.setdefault("background_normal", "")
        kw.setdefault("background_color", (0.18, 0.21, 0.30, 1))
        super().__init__(**kw)
        self.action = action
        self.repeat = repeat
        self._ev = None

    def on_press(self):
        self.action()
        if self.repeat:
            self._ev = Clock.schedule_once(self._start_repeat, 0.2)

    def _start_repeat(self, _dt):
        self._ev = Clock.schedule_interval(lambda _dt: self.action(), 0.06)

    def on_release(self):
        if self._ev is not None:
            self._ev.cancel()
            self._ev = None


# --------------------------------------------------------------------------
# App
# --------------------------------------------------------------------------
KEY_ACTIONS = {
    276: "left", 97: "left",            # Left, A
    275: "right", 100: "right",         # Right, D
    274: "soft_drop", 115: "soft_drop",  # Down, S
    273: "rotate", 120: "rotate", 119: "rotate",  # Up, X, W
    122: "rotate_ccw",                  # Z
    32: "hard_drop",                    # Space
    99: "hold", 303: "hold", 304: "hold",  # C, Shift
    112: "pause", 27: "pause",          # P, Esc
    114: "restart",                     # R
}

CLEAR_NAMES = {1: "Single", 2: "Double", 3: "Triple", 4: "BLOCK BLAST!"}


class BlockPuzzleApp(App):
    title = "Block Puzzle"

    def build(self):
        Window.clearcolor = (0.04, 0.05, 0.08, 1)
        self.board = Board()
        self.paused = False
        self.best = self._load_best()
        self.flash_text = ""
        self._flash_ev = None

        root = BoxLayout(orientation="vertical", padding=dp(8), spacing=dp(8))

        top = BoxLayout(spacing=dp(8))
        self.view = BoardView(self, size_hint_x=0.7)
        top.add_widget(self.view)

        side = BoxLayout(orientation="vertical", size_hint_x=0.3, spacing=dp(4))
        side.add_widget(self._heading("HOLD"))
        self.hold_view = PieceView(slots=1, size_hint_y=0.16)
        side.add_widget(self.hold_view)
        side.add_widget(self._heading("NEXT"))
        self.next_view = PieceView(slots=3, size_hint_y=0.40)
        side.add_widget(self.next_view)
        self.stats = Label(
            markup=True, halign="left", valign="top", font_size=sp(15),
            size_hint_y=0.44, color=(0.85, 0.88, 0.95, 1),
        )
        self.stats.bind(size=lambda w, s: setattr(w, "text_size", s))
        side.add_widget(self.stats)
        top.add_widget(side)
        root.add_widget(top)

        controls = GridLayout(cols=4, size_hint_y=None, height=dp(112), spacing=dp(6))
        a = self.act
        controls.add_widget(ControlButton(lambda: a("hold"), text="Hold"))
        controls.add_widget(ControlButton(lambda: a("rotate"), text="Rotate"))
        self.pause_btn = ControlButton(lambda: a("pause"), text="Pause")
        controls.add_widget(self.pause_btn)
        controls.add_widget(ControlButton(lambda: a("restart"), text="New",
                                          background_color=(0.45, 0.20, 0.25, 1)))
        controls.add_widget(ControlButton(lambda: a("left"), repeat=True, text="<"))
        controls.add_widget(ControlButton(lambda: a("soft_drop"), repeat=True, text="Down"))
        controls.add_widget(ControlButton(lambda: a("right"), repeat=True, text=">"))
        controls.add_widget(ControlButton(lambda: a("hard_drop"), text="Drop",
                                          background_color=(0.20, 0.40, 0.55, 1)))
        root.add_widget(controls)

        Window.bind(on_key_down=self._on_key_down)
        self._gravity_ev = Clock.schedule_once(self._gravity, self.board.gravity_interval)
        Clock.schedule_once(lambda _dt: self.refresh(), 0)
        return root

    def _heading(self, text):
        return Label(text=text, bold=True, font_size=sp(14), size_hint_y=None,
                     height=dp(22), color=(0.60, 0.65, 0.80, 1))

    # ---- game loop ------------------------------------------------------
    def can_play(self):
        return not self.paused and not self.board.game_over

    def _gravity(self, _dt):
        if self.can_play():
            self.board.tick()
            self._after_move()
        self._gravity_ev = Clock.schedule_once(self._gravity, self.board.gravity_interval)

    def act(self, name):
        b = self.board
        if name == "restart":
            b.reset()
            self.paused = False
            self.flash_text = ""
            self._restart_gravity()
        elif name == "pause":
            if not b.game_over:
                self.paused = not self.paused
        elif not self.can_play():
            return
        elif name == "left":
            b.move(-1, 0)
        elif name == "right":
            b.move(1, 0)
        elif name == "rotate":
            b.rotate(True)
        elif name == "rotate_ccw":
            b.rotate(False)
        elif name == "soft_drop":
            if b.soft_drop():
                self._restart_gravity()
        elif name == "hard_drop":
            b.hard_drop()
            self._restart_gravity()
        elif name == "hold":
            if b.hold_piece():
                self._restart_gravity()
        self._after_move()

    def _restart_gravity(self):
        if self._gravity_ev is not None:
            self._gravity_ev.cancel()
        self._gravity_ev = Clock.schedule_once(self._gravity, self.board.gravity_interval)

    def _after_move(self):
        b = self.board
        if b.last_clear:
            self._flash(CLEAR_NAMES[b.last_clear])
            b.last_clear = 0
        if b.score > self.best:
            self.best = b.score
            if b.game_over:
                self._save_best()
        elif b.game_over:
            self._save_best()
        self.refresh()

    def _flash(self, text):
        self.flash_text = text
        if self._flash_ev is not None:
            self._flash_ev.cancel()
        self._flash_ev = Clock.schedule_once(self._clear_flash, 1.2)

    def _clear_flash(self, _dt):
        self.flash_text = ""
        self.refresh()

    def refresh(self):
        b = self.board
        self.view.redraw()
        self.hold_view.show([b.hold], dim=not b.can_hold)
        self.next_view.show(b.queue)
        self.pause_btn.text = "Resume" if self.paused else "Pause"
        flash = f"\n\n[color=ffd447][b]{self.flash_text}[/b][/color]" if self.flash_text else ""
        self.stats.text = (
            f"[color=8a93b3]SCORE[/color]\n[size={int(sp(22))}][b]{b.score}[/b][/size]\n\n"
            f"[color=8a93b3]LEVEL[/color]\n[b]{b.level}[/b]\n\n"
            f"[color=8a93b3]LINES[/color]\n[b]{b.lines}[/b]\n\n"
            f"[color=8a93b3]BEST[/color]\n[b]{self.best}[/b]{flash}"
        )

    # ---- input ----------------------------------------------------------
    def _on_key_down(self, _window, key, _scancode, _codepoint, _modifiers):
        action = KEY_ACTIONS.get(key)
        if action:
            self.act(action)
            return True
        return False

    # ---- persistence ----------------------------------------------------
    def _best_path(self):
        return os.path.join(self.user_data_dir, "block_puzzle.json")

    def _load_best(self):
        try:
            with open(self._best_path()) as f:
                return int(json.load(f).get("best", 0))
        except (OSError, ValueError):
            return 0

    def _save_best(self):
        try:
            with open(self._best_path(), "w") as f:
                json.dump({"best": self.best}, f)
        except OSError:
            pass

    # ---- mobile lifecycle -----------------------------------------------
    def on_pause(self):
        self.paused = True
        self.refresh()
        return True

    def on_stop(self):
        self._save_best()


if __name__ == "__main__":
    BlockPuzzleApp().run()
